package vldb;

public class Constants {
	public final static int TIMEOUT = 1000;
}
