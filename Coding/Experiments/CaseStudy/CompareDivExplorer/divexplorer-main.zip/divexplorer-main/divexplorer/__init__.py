"""divexplorer - DivExplorer"""

__version__ = '0.1.0'
__author__ = 'Eliana Pastor <eliana.pastor@polito.it>'
__all__ = []
